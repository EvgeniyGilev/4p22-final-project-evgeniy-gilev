export default function Page404() {
  return <h1>Страница, которую вы ищите не найдена. Проверьте адрес.</h1>;
}
